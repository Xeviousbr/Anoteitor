﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Anoteitor {
    public static class CONST {
        public const string CannotFindMessage = "Não achei \"{SearchText}\"";
    }
}
